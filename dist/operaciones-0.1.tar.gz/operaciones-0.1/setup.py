from setuptools import setup

setup(name="operaciones",
      version="0.1",
      author="santiago castaño",
      author_email="santiago.castanomoreno03@gmail.com",
      description="operaciones basicas",
      packages=["operaciones"])
